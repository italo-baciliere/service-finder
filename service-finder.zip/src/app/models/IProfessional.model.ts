export interface IProfessional{
  photo: string;
  nome: string;
  category: string[];
  distance: number;
  score: string;
}
